<div class="page-footer pt-4 foot_div ">
  <div class="col-lg-12 col-md-12" style="padding-bottom:10px;">

    <div class="text-center">
  </div>

    <p class="text-center text-light" style="padding-top:20px;margin-top:-30px;"> Copyright Virlich Softworks &reg; <?php echo date('Y'); ?></p>
  </div>
</div><!-- footer end of row-->
